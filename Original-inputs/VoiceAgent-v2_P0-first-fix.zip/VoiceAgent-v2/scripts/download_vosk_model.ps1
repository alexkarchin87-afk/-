# Скачивает русскую small-модель Vosk в app/src/main/assets/model-ru-small и создаёт файл uuid.
# Запуск (PowerShell, из любой папки):  powershell -ExecutionPolicy Bypass -File scripts\download_vosk_model.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $root "app\src\main\assets\model-ru-small"
$zip  = Join-Path $env:TEMP "vosk-model-small-ru-0.22.zip"
$tmp  = Join-Path $env:TEMP "vosk-model-small-ru-unpack"

Invoke-WebRequest "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip" -OutFile $zip
if (Test-Path $tmp)  { Remove-Item $tmp  -Recurse -Force }
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
Expand-Archive $zip $tmp
New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
Move-Item (Get-ChildItem $tmp | Select-Object -First 1).FullName $dest
[guid]::NewGuid().ToString() | Set-Content (Join-Path $dest "uuid") -NoNewline -Encoding ascii
Write-Host "Готово: $dest"
