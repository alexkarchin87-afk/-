#!/bin/sh
# Linux/macOS/Termux: скачивает модель Vosk в app/src/main/assets/model-ru-small и создаёт uuid.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/assets/model-ru-small"
TMP="$(mktemp -d)"
curl -L -o "$TMP/m.zip" https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip
unzip -q "$TMP/m.zip" -d "$TMP"
rm -rf "$DEST"; mkdir -p "$(dirname "$DEST")"
mv "$TMP"/vosk-model-small-ru-* "$DEST"
cat /proc/sys/kernel/random/uuid > "$DEST/uuid" 2>/dev/null || date +%s > "$DEST/uuid"
echo "Готово: $DEST"
