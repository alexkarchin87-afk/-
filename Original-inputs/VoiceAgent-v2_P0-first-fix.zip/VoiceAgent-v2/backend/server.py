"""
Minimal job queue backend for VoiceAgent's ThreeDOrchestrator / RemoteWorkerClient.
Runs on a machine with real compute (GPU workstation, VPS) at AGENT_WORKER_URL.
The phone submits jobs, this service (or a worker process reading from the same
store) executes them and updates status; the phone polls GET /jobs/{id}.

This is intentionally a thin reference implementation — plug in your own executor
(Blender headless render, a game-streaming session, etc.) inside `run_job_stub`.
"""
import os
import uuid
import time
import json
import threading
from enum import Enum
from typing import Any, Dict, List, Optional

import httpx

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# Подхватывает backend/.env при прямом запуске (uvicorn server:app --app-dir backend).
# При запуске через docker-compose эту же переменную подставляет сам compose
# (см. docker-compose.yml) — load_dotenv() тут не мешает, просто не находит
# файл внутри контейнера и молча ничего не делает.
load_dotenv()

WORKER_TOKEN = os.environ.get("AGENT_WORKER_TOKEN", "change-me")
if WORKER_TOKEN == "change-me":
    print(
        "[VoiceAgent Worker] ВНИМАНИЕ: AGENT_WORKER_TOKEN не задан (или backend/.env "
        "не найден/не подхватился) — используется значение по умолчанию 'change-me'. "
        "Скопируй backend/.env.example в backend/.env и впиши свой токен."
    )

app = FastAPI(title="VoiceAgent Worker")


class Job3DStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    DONE = "DONE"
    FAILED = "FAILED"


class Job3D(BaseModel):
    id: str
    kind: str
    params_json: str
    status: Job3DStatus = Job3DStatus.QUEUED
    result_url: Optional[str] = None
    error_message: Optional[str] = None


class SubmitJobRequest(BaseModel):
    kind: str
    params_json: str


JOBS: Dict[str, Job3D] = {}


def require_auth(authorization: str = Header(default="")):
    token = authorization.removeprefix("Bearer ").strip()
    if token != WORKER_TOKEN:
        raise HTTPException(status_code=401, detail="invalid worker token")


def run_job_stub(job_id: str):
    """Replace this with your real executor. Kept synchronous + backgrounded via thread
    for simplicity; swap for a proper task queue (RQ/Celery) for production use."""
    job = JOBS[job_id]
    job.status = Job3DStatus.RUNNING
    time.sleep(5)  # simulate work
    job.status = Job3DStatus.DONE
    job.result_url = f"https://your-vps.example.com/results/{job_id}.png"


@app.post("/jobs", response_model=Job3D)
def submit_job(req: SubmitJobRequest, authorization: str = Header(default="")):
    require_auth(authorization)
    job = Job3D(id=str(uuid.uuid4()), kind=req.kind, params_json=req.params_json)
    JOBS[job.id] = job
    threading.Thread(target=run_job_stub, args=(job.id,), daemon=True).start()
    return job


@app.get("/jobs/{job_id}", response_model=Job3D)
def get_job(job_id: str, authorization: str = Header(default="")):
    require_auth(authorization)
    job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="job not found")
    return job


DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
# Id модели задаётся через env: впиши DEEPSEEK_MODEL=<id DeepSeek v4 из их документации>, когда он есть в API.
DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
# Модель для запросов со снимком экрана (текстовые модели картинки не принимают).
DEEPSEEK_VISION_MODEL = os.environ.get("DEEPSEEK_VISION_MODEL", "deepseek-v4-flash-vision-exp")


class ChatStreamRequest(BaseModel):
    messages: List[Dict[str, Any]]  # content: строка или список частей (text + image_url)
    temperature: float = 0.7


def _sse(obj: dict) -> str:
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


@app.post("/chat/stream")
async def chat_stream(req: ChatStreamRequest, authorization: str = Header(default="")):
    require_auth(authorization)
    api_key = os.environ.get("DEEPSEEK_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=500, detail="DEEPSEEK_API_KEY is not set")

    async def generate_stream():
        has_image = any(isinstance(m.get("content"), list) for m in req.messages)
        payload = {"model": DEEPSEEK_VISION_MODEL if has_image else DEEPSEEK_MODEL, "messages": req.messages,
                   "temperature": req.temperature, "stream": True}
        headers = {"Authorization": f"Bearer {api_key}"}
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(180.0, connect=10.0)) as client:
                async with client.stream("POST", DEEPSEEK_URL, json=payload, headers=headers) as r:
                    if r.status_code != 200:
                        body = (await r.aread()).decode(errors="replace")[:300]
                        yield _sse({"error": f"DeepSeek {r.status_code}: {body}"})
                        return
                    async for line in r.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            piece = json.loads(data)["choices"][0]["delta"].get("content")
                        except (ValueError, KeyError, IndexError):
                            continue
                        if piece:  # reasoning_content (мысли R1) намеренно не стримим
                            yield _sse({"text": piece})
        except httpx.HTTPError as e:
            yield _sse({"error": f"network: {e}"})  # после старта стрима код ответа уже 200
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        generate_stream(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/health")
def health():
    return {"ok": True}
