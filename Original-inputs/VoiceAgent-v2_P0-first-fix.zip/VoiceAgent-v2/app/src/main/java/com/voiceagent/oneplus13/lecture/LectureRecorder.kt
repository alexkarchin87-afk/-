package com.voiceagent.oneplus13.lecture

import android.content.Context
import com.voiceagent.oneplus13.core.STTEngine
import com.voiceagent.oneplus13.core.AgentEvent
import com.voiceagent.oneplus13.core.AgentEventBus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Drives STTEngine specifically for long-form lecture capture: continuously
 * appends recognized chunks to the active LectureSession via LectureChunkProcessor,
 * independent of the normal command-listening loop in VoiceAgentService.
 */
class LectureRecorder(context: Context) {

    private val stt = STTEngine(context)
    private val scope = CoroutineScope(Job())
    private var listening = false
    private var job: Job? = null

    fun start(session: LectureSession, chunkProcessor: LectureChunkProcessor) {
        if (listening) return
        listening = true
        stt.ensureModel(
            onReady = {
                job = scope.launch {
                    try {
                        stt.listen().collect { chunk ->
                            chunkProcessor.process(session, chunk)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Сбой микрофона/распознавателя не должен ронять приложение.
                        listening = false
                        AgentEventBus.publish(AgentEvent.Error("Запись лекции прервалась", e))
                    }
                }
            },
            onError = { listening = false /* surfaced via AgentEventBus by the caller */ }
        )
    }

    fun stop() {
        listening = false
        job?.cancel()
        job = null
        stt.stop()
    }
}
