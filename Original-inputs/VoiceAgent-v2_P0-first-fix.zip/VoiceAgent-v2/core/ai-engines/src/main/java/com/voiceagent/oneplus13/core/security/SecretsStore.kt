package com.voiceagent.oneplus13.core.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Encrypted key-value store for secrets added AT RUNTIME (API keys typed into
 * Settings, bot tokens captured from Telegram notifications) — as opposed to
 * BuildConfig fields, which only cover secrets baked in at compile time via
 * local.properties.
 *
 * Backed by Jetpack Security's EncryptedSharedPreferences (AES-256-GCM), so
 * values are encrypted at rest even on a rooted device without extra work.
 */
class SecretsStore(context: Context) {

    private val prefs: SharedPreferences = openEncryptedPrefs(context)

    private val keyIndex = context.getSharedPreferences("voice_agent_secret_index", Context.MODE_PRIVATE)

    fun put(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
        // Only the KEY NAME (a label like "project_secret:my_bot:TELEGRAM_BOT_TOKEN") is
        // recorded here, in plain SharedPreferences, purely so Settings can list which
        // secrets exist without decrypting everything. The secret VALUE only ever lives
        // in the encrypted store above.
        if (key.startsWith("project_secret:")) {
            keyIndex.edit().putBoolean(key, true).apply()
        }
    }

    fun get(key: String): String? = prefs.getString(key, null)

    /** Имена секретов сгенерированных проектов (только имена, не значения — см. put()). */
    fun projectSecretKeys(): List<String> = keyIndex.all.keys.toList()

    fun remove(key: String) {
        prefs.edit().remove(key).apply()
    }

    /** Convenience: value from SecretsStore if the user has set one, else [fallback]
     *  (typically a BuildConfig field from local.properties). Lets runtime-entered
     *  keys in Settings override compile-time ones without a rebuild. */
    fun getOrDefault(key: String, fallback: String): String = get(key)?.takeIf { it.isNotBlank() } ?: fallback

    companion object {
        private const val TAG = "SecretsStore"
        private const val FILE_NAME = "voice_agent_secrets"

        /**
         * Если файл секретов восстановлен из бэкапа (или приложение переустановили), а ключ
         * шифрования в Android Keystore остался прежним/пропал, EncryptedSharedPreferences
         * падает при открытии — раньше это валило приложение и выглядело как «всё сбросилось».
         * Расшифровать такой файл нельзя в принципе, поэтому удаляем его и начинаем с чистого
         * (ключи придётся ввести заново), но приложение запускается.
         */
        private fun openEncryptedPrefs(context: Context): SharedPreferences {
            fun open(): SharedPreferences {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                return EncryptedSharedPreferences.create(
                    context,
                    FILE_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }
            return try {
                open()
            } catch (e: Exception) {
                Log.w(TAG, "encrypted prefs unreadable, recreating", e)
                context.deleteSharedPreferences(FILE_NAME)
                open()
            }
        }

        const val KEY_DEEPSEEK_API_KEY = "deepseek_api_key"
        const val KEY_CLAUDE_API_KEY = "claude_api_key"
        const val KEY_TELEGRAM_BOT_TOKEN = "telegram_bot_token"
        const val KEY_MAX_SERVICE_TOKEN = "max_service_token"

        /** Prefix for tokens captured automatically from BotFather notifications,
         *  one per generated project: pending_botfather_token:<project_name> */
        fun pendingBotFatherTokenKey(projectName: String) = "pending_botfather_token:$projectName"
    }
}
