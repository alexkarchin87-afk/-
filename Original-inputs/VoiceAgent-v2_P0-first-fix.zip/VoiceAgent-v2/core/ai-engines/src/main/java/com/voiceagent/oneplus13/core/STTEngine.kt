package com.voiceagent.oneplus13.core

import android.content.Context
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Offline speech-to-text using Vosk. Runs fully on-device so lecture recording and
 * wake-word listening keep working without network.
 *
 * Model must be unpacked once (see [ensureModel]) from assets or downloaded into
 * app-internal storage; a small Russian model (~50MB) is recommended for this use case.
 *
 * Освобождение SpeechService идемпотентно: stop() и отмена коллектора Flow раньше
 * оба вызывали shutdown() -> Recognizer.close() дважды (двойное освобождение нативной
 * памяти Vosk = возможный SIGSEGV).
 */
class STTEngine(private val context: Context) {

    @Volatile private var model: Model? = null
    @Volatile private var releaseCurrent: (() -> Unit)? = null

    /** Unpacks the bundled Vosk model (assets/model-ru-small) into internal storage if needed. */
    fun ensureModel(modelAssetPath: String = "model-ru-small", onReady: (Model) -> Unit, onError: (Throwable) -> Unit) {
        val cached = model
        if (cached != null) {
            onReady(cached)
            return
        }
        StorageService.unpack(context, modelAssetPath, "model",
            { unpackedModel -> model = unpackedModel; onReady(unpackedModel) },
            { ex -> Log.e("STTEngine", "model unpack failed", ex); onError(ex) }
        )
    }

    /**
     * Фаза 1 — офлайн-ожидание слова-вызова. Recognizer с грамматикой ["ваня"] (дёшево по CPU).
     * Возвращается, как только слово услышано; к этому моменту сессия микрофона уже закрыта,
     * можно сразу вызывать [listen] (полнотекстовый Recognizer). Событие в AgentEventBus
     * публикует вызывающий — модуль не видит :app. Грамматика работает на small-моделях
     * (vosk-model-small-ru); у больших моделей со статическим графом она не поддерживается.
     */
    suspend fun awaitWakeWord(wakeWord: String = "ваня"): Unit = suspendCancellableCoroutine { cont ->
        val currentModel = model
        if (currentModel == null) {
            cont.resumeWithException(IllegalStateException("Call ensureModel() first"))
            return@suspendCancellableCoroutine
        }
        releaseCurrent?.invoke()

        val recognizer = Recognizer(currentModel, 16000.0f, "[\"$wakeWord\"]")
        val service = try {
            SpeechService(recognizer, 16000.0f)
        } catch (e: Exception) {
            recognizer.close()
            cont.resumeWithException(e)
            return@suspendCancellableCoroutine
        }

        val released = AtomicBoolean(false)
        val release: () -> Unit = {
            if (released.compareAndSet(false, true)) {
                runCatching { service.stop() }      // join потока записи ДО закрытия Recognizer
                runCatching { service.shutdown() }
            }
        }
        releaseCurrent = release

        fun check(json: String?, key: String) {
            val heard = runCatching { JSONObject(json ?: return).optString(key) }.getOrDefault("")
            if (heard.contains(wakeWord, ignoreCase = true) && cont.isActive) {
                release()
                if (releaseCurrent === release) releaseCurrent = null
                cont.resume(Unit)
            }
        }

        val started = service.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial") // быстрый отклик
            override fun onResult(hypothesis: String?) = check(hypothesis, "text")
            override fun onFinalResult(hypothesis: String?) = check(hypothesis, "text")
            override fun onError(exception: Exception?) {
                release()
                if (cont.isActive) cont.resumeWithException(exception ?: IllegalStateException("Vosk error"))
            }
            override fun onTimeout() {}
        })
        if (!started) {
            release()
            cont.resumeWithException(IllegalStateException("Микрофон уже занят другой записью"))
            return@suspendCancellableCoroutine
        }
        cont.invokeOnCancellation { release() }
    }

    /** Continuous final-phrase recognition as a cold Flow; cancel the collector to stop listening. */
    fun listen(): Flow<String> = callbackFlow {
        val currentModel = model ?: throw IllegalStateException("Call ensureModel() first")
        releaseCurrent?.invoke() // одновременно живёт только одна сессия микрофона

        val recognizer = Recognizer(currentModel, 16000.0f)
        val service = try {
            SpeechService(recognizer, 16000.0f)
        } catch (e: Exception) {
            recognizer.close()
            throw e
        }

        val released = AtomicBoolean(false)
        val release: () -> Unit = {
            if (released.compareAndSet(false, true)) {
                runCatching { service.stop() }
                runCatching { service.shutdown() }
            }
        }
        releaseCurrent = release

        val started = service.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) { /* ignored: UI only needs finals */ }

            override fun onResult(hypothesis: String?) {
                val text = hypothesis?.let { JSONObject(it).optString("text") }.orEmpty()
                if (text.isNotBlank()) trySend(text)
            }

            override fun onFinalResult(hypothesis: String?) {
                val text = hypothesis?.let { JSONObject(it).optString("text") }.orEmpty()
                if (text.isNotBlank()) trySend(text)
            }

            override fun onError(exception: Exception?) {
                close(exception)
            }

            override fun onTimeout() { /* no-op: keep listening */ }
        })
        if (!started) close(IllegalStateException("Микрофон уже занят другой записью"))

        awaitClose {
            release()
            if (releaseCurrent === release) releaseCurrent = null
        }
    }

    fun stop() {
        releaseCurrent?.invoke()
        releaseCurrent = null
    }
}
